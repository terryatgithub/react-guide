export default function Component(props) {
  this.props = props;
}

Component.prototype.isReactComponent = {};
