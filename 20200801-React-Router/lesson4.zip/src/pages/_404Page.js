import React, {Component} from "react";

export default class _404Page extends Component {
  render() {
    return (
      <div>
        <h3>_404Page</h3>
      </div>
    );
  }
}
