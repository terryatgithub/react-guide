import React, {Component} from "react";

export default class WelcomePage extends Component {
  render() {
    return (
      <div>
        <h3>WelcomePage</h3>
      </div>
    );
  }
}
